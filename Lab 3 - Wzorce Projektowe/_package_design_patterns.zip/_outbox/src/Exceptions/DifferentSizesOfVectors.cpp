//
// Created by user on 2016-11-24.
//

#include "DifferentSizesOfVectors.h"

const char* DifferentSizesOfVectors::what() const throw(){
    return Reason.c_str();
}