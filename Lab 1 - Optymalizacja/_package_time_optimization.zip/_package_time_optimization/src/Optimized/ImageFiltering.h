#pragma once
class CImageFiltering
{
public:
	CImageFiltering(void) {}

	void ImageFiltering(BYTE* pInImg, int nW, int nH, BYTE* pOutImg);
};

