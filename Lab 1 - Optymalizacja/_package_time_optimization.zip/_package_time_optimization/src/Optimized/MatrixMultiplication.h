#pragma once
#include "ITest.h"

class CMatrixMultiplication
{
public:
	CMatrixMultiplication(void) {}

	void MatrixMultiplication(CMatrix& first, CMatrix& second, CMatrix& res);
};

