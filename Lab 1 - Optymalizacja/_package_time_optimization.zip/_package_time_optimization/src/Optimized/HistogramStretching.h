#pragma once

class CHistogramStretching
{
public:
	CHistogramStretching(void){}

	void HistogramStretching(BYTE** pImage, int nW, int nH);
};

